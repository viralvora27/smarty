<?php
ob_start();
class admin extends Controller
{
  protected $logger;
  protected $smarty;
  protected $client;
  protected $users;

   protected $config;

  function __construct()
  {
    $this->logger = $this->loadLogger();
    $this->logger = Logger::getLogger("index");
        $this->smarty = $this->loadSmarty(); // load from function
        $this->users  = $this->loadModel("AdminLogin");
        /* $this->config=$this->loadModel("ConfigParameters"); */
   
        $this->client = $this->loadLibrary("SimpleHTTPClient");
       
      }
      

      function login()
      {
        if (count($_POST)) {
          $adminname  = $_POST['adminname'];
          $password   = $_POST['password'];
          $password=md5($password);
          
        

          $adminlogin = $this->loadModel('AdminLogin');

          $admin_id = $adminlogin->login($adminname, $password);
        

          if ($admin_id>0) {
            $_SESSION['admin'] = $admin_id;
            
              $this->redirect( "admin/dashboard");

          } else {
            $dt='Username or password might be wrong';
          $this->smarty->assign("message",$dt);
          $this->smarty->display('admin/login.tpl');
        }

      } else {
        $dt=null;
        $this->smarty->assign("message",$dt);
        $this->smarty->display('admin/login.tpl');

      }
    }
	
	 function logout()
    {
      session_destroy();
      unset($_SESSION['admin']);
      $this->redirect( "admin/login");

    }
    
    function dashboard()
    {
      if (isset($_SESSION["admin"])) {
     
	  $isDel=0;
	 $stu_detail = $this->loadModel('student');

          $stu_data = $stu_detail->studentDetail($isDel);
		  $this->smarty->assign("data", $stu_data);
		  
        $this->smarty->display('admin/dashboard.tpl');
      } else {
       $this->redirect( "admin/login");        
      }

    }

function addcategory()
{
  if(count($_POST))
  {
    $categoryName=$_POST["txtName"];
   // $createdDate=date("Y-m-d");
   $txtemail=$_POST["txtemail"];
   $txtmobile=$_POST["txtmobile"];
    $isDeleted="0"; 
    $image="";
    $category = $this->loadModel("student");
    $categoryId = $category->addCategory($categoryName,$txtemail,$txtmobile,$image,$isDeleted);
    
    if(isset($_FILES['image']))
    {
      $errors= array();
    if($_FILES['image']['size']!=0)
    {
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];   
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      $extensions = array("jpeg","jpg","png");    
      if(in_array($file_ext,$extensions )=== false)
      {
     //$errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      if($file_size > 2097152)
      {
    //$errors[]='File size must be excately 2 MB';
      }       
      if(empty($errors)==true)
      {


        if (file_exists("category/".$categoryId))
        {
          
        }
        else
        {
         @mkdir("category/".$categoryId); 
         
       }
       @move_uploaded_file($file_tmp,"category/".$categoryId."/".$file_name);
       
       $image= $file_name;
       
       //echo $categoryId;
        // image path update//
		$category = $this->loadModel("student");
       $category_data= $category->updateCategoryImage($categoryId,$image);
       
        // image path update//
     }
   }
 }
  //$dt='Student Added Successfully';
  // $this->smarty->assign("message",$dt);
 $this->redirect( "admin/addcategory&category=".'1');
// $this->smarty->display("admin/addcategory&category=".'1');
 }
 else
 {
  $dt=null;
  $this->smarty->assign("message",$dt);
  $this->smarty->display("admin/addcategory.tpl");
}
}

	
 function editcategory()
 {
   if(count($_POST))
  {
   $categoryId=$_GET["id"];
   
   $category = $this->loadModel("student");
  // $categoryId=$_POST["categoryId"];
  // echo $categoryId;

   if(isset($_FILES['image']))
   {
    $errors= array();
    if($_FILES['image']['size']!=0)
    {
    $file_name = $_FILES['image']['name'];
    $file_size =$_FILES['image']['size'];
    $file_tmp =$_FILES['image']['tmp_name'];
    $file_type=$_FILES['image']['type'];   
    $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
    $extensions = array("jpeg","jpg","png");    
    if(in_array($file_ext,$extensions )=== false)
    {
     //$errors[]="extension not allowed, please choose a JPEG or PNG file.";
    }
    if($file_size > 2097152)
    {
    //$errors[]='File size must be excately 2 MB';
    }       
    if(empty($errors)==true)
    {
      if (file_exists("category/".$categoryId))
      {
        
      }
      else
      {
       @mkdir("category/".$categoryId); 
       
     }
     @move_uploaded_file($file_tmp,"category/".$categoryId."/".$file_name);
     
     $image= $file_name;
     
   }
 }
}
 if($image=="")
 {
	 $image=$_POST["txtimg"];
 /* $category = $this->loadModel("student");
  $category_data = $category->loadCategoryById($categoryId);
  while($row=mysql_fetch_array($category_data))
  {
    $image=$row["image"];
  }*/
  
  //echo $image;
}

$categoryName=$_POST["txtName"];
$email=$_POST["txtemail"];
$mob=$_POST["txtmobile"];
//$image=$_POST["image"];

//$createdDate=date("Y-m-d");
$isDeleted="0";
$category = $this->loadModel("student");
$category_data =$category->updateCategory($categoryId,$categoryName,$email,$mob,$image);
 $this->smarty->assign("data", $category_data);
  /*$dt='Username or password might be wrong';
          $this->smarty->assign("message",$dt);*/
$this->redirect( "admin/editcategory&id=$categoryId&updatecategory=".'1');

}
else
{
 $categoryId=$_GET['id'];
  //$categoryId=$_POST["categoryId"];
 $category = $this->loadModel( "student" );
 $category_data = $category->loadCategoryById($categoryId);

  $this->smarty->assign("data", $category_data);
        $this->smarty->display('admin/editcategory.tpl');
}
    }
	
function deleteCategoryById()
 {
	  $catid= $_GET['categoryId'];
	 // var_dump($catid);
     if (!empty($catid))
	 { 
		$id=$catid;	
      $category = $this->loadModel("student");
     
		 $deleted=1;
        $category_data=$category->deleteCategoryById($deleted,$id);
		if($category_data=="1")
		{
        echo  $catid;
        // return $catid;
		}
		else
		{
			echo 0;
		}
 }
 else
 {
	  echo 0;// error or wrong
	 //return 0;
  
 }
}

    
  }  /* end class */
?>