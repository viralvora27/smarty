<?php

class Application
{
	public $uri; 

	function __construct( $uri = null )
	{
		$this->uri = $uri;

		$this->loadController( $uri['controller'] );
	}

	function loadController( $class )
	{
		$file = "application/controllers/".$this->uri['controller'].".php";

		if(!file_exists($file)) die( "controller not found at $file" );

		require_once($file);

		$controller = new $class();

		if( method_exists( $controller, $this->uri['method'] ) ){
			$controller->{$this->uri['method']}( $this->uri['var'] );
		} 
		else {
			$controller->index();
		}
	}
}

class Model
{ 
	
    public function __construct ()
    {
    	
    }
    function open()
    {
        require( 'config.php' );
        $connection = new mysqli($server, $user, $pass, $dbname);

		if($connection->connect_errno > 0){
		    die('Unable to connect to database [' . $db->connect_error . ']');
		}

        $connection->set_charset('utf8');
        return $connection;
    }
    function close($db)
    {
    	if(isset($db))
    	{
    		 mysqli_close($db);
    	}
    	
    	 

    }
    
}

class Controller
{
	function loadModel( $model )
	{

		require_once( 'application/models/'. $model .'.php' );
		return new $model();
		/*require( 'config.php' ); // pass database object

		$db = new mysqli($server, $user, $pass, $dbname);
		if($db->connect_errno > 0){
    		die('Unable to connect to database [' . $db->connect_error . ']');
		}
		return new $model($db);*/
	} 

	function loadLibrary( $helper )
	{
		require_once( 'application/config/'. $helper .'.php' );
		return new $helper;
	} 


	function loadView( $view, $vars="" )
	{
		if(is_array($vars) && count($vars) > 0) extract($vars, EXTR_PREFIX_SAME, "wddx");
		require_once( 'application/views/'.$view.'.html' );
	}

	function redirect( $uri )
	{
		header( "Location: index.php?route=$uri" );
		
		die();
	}

	function loadSmarty()
	{
		require_once('libs/smarty/Smarty.class.php');
		$smarty = new Smarty();
		$smarty->caching = false;
		$smarty->cache_lifetime = 120;

		$smarty->setTemplateDir('application/views/templates');
        $smarty->setCompileDir('application/views/templates_c');
        $smarty->setCacheDir('application/views/cache');


		return $smarty;
	} 

	function loadLogger()
	{
		require_once('libs/log4php/Logger.php');
		Logger::configure(SITE_PATH.'/config/log4php/config.xml');
		
	} 

	function securityCheck( $value )
	{
		
		$value=strip_tags($value);
		$value=htmlspecialchars($value);
		$value=trim($value);

		return $value;
		
		
	}
}
