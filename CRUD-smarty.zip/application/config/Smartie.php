<?php
require_once(LIBRARY_PATH.'/smarty/Smarty.class.php');
class Smartie extends Smarty {

    var $debug = false;

    function __construct()
    {
        parent::__construct();

        $this->template_dir = "application/views/templates";
        $this->compile_dir = "application/views/templates_c";
        if ( ! is_writable( $this->compile_dir ) )
        {
            // make sure the compile directory can be written to
            @chmod( $this->compile_dir, 0777 );
        } 

        // Uncomment these 2 lines to change Smarty's delimiters
        // $this->left_delimiter = '{{';
        // $this->right_delimiter = '}}';

       // $this->assign( 'FCPATH', FCPATH );     // path to website
       // $this->assign( 'APPPATH', APPPATH );   // path to application directory
       // $this->assign( 'BASEPATH', BASEPATH ); // path to system directory

        //log_message('debug', "Smarty Class Initialized");
    }

    function setDebug( $debug=true )
    {
        $this->debug = $debug;
    }
}