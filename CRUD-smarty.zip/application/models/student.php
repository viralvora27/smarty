<?php 

class student extends Model {

    protected $id;
	protected $name;
    protected $email;
    protected $mob;
    protected $image;
	protected $isDeleted;


    function __construct()
    {
        parent::__construct();
        $this->table_name = 'student';
        
		 $this->id='id';
        $this->name='name';
        $this->email='email';
         $this->mob='mob';
		  $this->image='image';
		  $this->isDeleted='isDeleted';
    }


    function studentDetail($isDel)
    {

           //Open connection
        $db=$this->open();

        
        $stmt = $db->prepare("SELECT $this->id,$this->name,$this->email,$this->mob,$this->image FROM $this->table_name WHERE isDeleted=?");

        $stmt->bind_param('i', $isDel);
		
        /* execute query */
        $stmt->execute();

	    $stmt->bind_result($id,$name,$email,$mob,$image);
     
        $studentArray = array();
		 
         while ($stmt->fetch()) 
        {
       
          $student = array("id"=>$id,"name"=>$name,"email"=>$email,"mob"=>$mob,"image"=>$image);
          array_push($studentArray, $student);
        }
      
  
       $stmt->free_result();
       $stmt->close();
       $this->close($db);

        return $studentArray;


    }

    function existCategoryById ( $id ) 
	{
		 $db=$this->open();
		 
		$sql = $db->prepare("SELECT $this->name,$this->email,$this->mob,$this->image FROM $this->table_name WHERE id=?  LIMIT 1");
		
		 $stmt->bind_param('i', $categoryId);
		 
		$stmt->execute();

	    $stmt->bind_result($name,$email,$mob,$image);
     
        $studentArray = array();
		 
         while ($stmt->fetch()) 
        {
       
          $student = array("name"=>$name,"email"=>$email,"mob"=>$mob,"image"=>$image);
          array_push($studentArray, $student);
        }
      
  
       $stmt->free_result();
       $stmt->close();
       $this->close($db);

        return $studentArray;

	}
	

	function deleteCategoryById($deleted,$id)
	{

		$db=$this->open();
		 
		$sql = "UPDATE $this->table_name SET $this->isDeleted=? WHERE id=?";
		
		 $stmt = $db->prepare($sql);
		 
		$stmt->bind_param('ii',$deleted,$id);

        $stmt->execute();  
        
        $affected_rows = $stmt->affected_rows;
        $stmt->free_result();
        $stmt->close();
        $this->close($db);

        return $affected_rows;
		
	}
	
	function addCategory($categoryName,$txtemail,$txtmobile,$image,$isDeleted)
	{
       $db=$this->open();
	   
		 $stmt = $db->prepare("INSERT  INTO  $this->table_name($this->name,$this->email,$this->mob,$this->image,$this->isDeleted) VALUES(?,?,?,?,?)");
		        
		$stmt->bind_param('ssssi',$categoryName,$txtemail,$txtmobile,$image,$isDeleted);
		
		 $stmt->execute();

        $newId = $stmt->insert_id;
        $stmt->free_result();
        $stmt->close();
        $this->close($db);

        return $newId;
	}
	
	function updateCategoryImage($categoryId,$image)
	{

		 $db=$this->open();
	   
		 $sql = "UPDATE $this->table_name SET $this->image=? WHERE id=?";
		 
		 $stmt = $db->prepare($sql);
		 
		$stmt->bind_param('si',$image,$categoryId);

        $stmt->execute();  
        
        $affected_rows = $stmt->affected_rows;
        $stmt->free_result();
        $stmt->close();
        $this->close($db);

        return $affected_rows;
	}
	
	function updateCategory($categoryId,$categoryName,$email,$mob,$image)
	{
		$db=$this->open();

		$sql = "UPDATE  $this->table_name SET $this->name=?,$this->email=?,$this->mob=?,$this->image=? WHERE id=?";
		 
		$stmt = $db->prepare($sql);
		 
		$stmt->bind_param('ssssi',$categoryName,$email,$mob,$image,$categoryId);

        $stmt->execute();  
        
        $affected_rows = $stmt->affected_rows;
        $stmt->free_result();
        $stmt->close();
        $this->close($db);

        return $affected_rows;
	}
	
	function loadCategoryById($categoryId) 
	{
		 $db=$this->open();

        
        $stmt = $db->prepare("SELECT $this->id,$this->name,$this->email,$this->mob,$this->image FROM $this->table_name WHERE id=?");

        $stmt->bind_param('i', $categoryId);
		
        /* execute query */
        $stmt->execute();

	    $stmt->bind_result($id,$name,$email,$mob,$image);
     
        $studentArray = array();
		 
         while ($stmt->fetch()) 
        {
       
          $student = array("id"=>$id,"name"=>$name,"email"=>$email,"mob"=>$mob,"image"=>$image);
          array_push($studentArray, $student);
        }
      
  
       $stmt->free_result();
       $stmt->close();
       $this->close($db);

        return $studentArray;
		
		
	}
	
	
    

}

?>