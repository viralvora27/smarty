<?php 

class AdminLogin extends Model {

	protected $adminname;
    protected $password;
    


    function __construct()
    {
        parent::__construct();
        $this->table_name = 'admin_login';
        
        $this->adminname='adminname';
        $this->password='password';
        
    }


    function login($adminname,$password)
    {

           //Open connection
        $db=$this->open();

        
        $stmt = $db->prepare("SELECT id FROM $this->table_name WHERE adminname=? AND password=? LIMIT 1");

        

        $stmt->bind_param('ss', $adminname, $password);

        /* execute query */
        $stmt->execute();

        $stmt->bind_result($id);
        $result=$stmt->fetch();

        

        $stmt->close();

        
        
        $this->close($db);

        return $id;

    }

    function ChangePassword($id,$newpassword)
    {

        $db=$this->open();
        
        $sql="UPDATE $this->table_name SET $this->password=? WHERE id =?";       
       

        $stmt = $db->prepare($sql);
      
        $stmt->bind_param('si',$newpassword,$id);

        $stmt->execute();  
        
        $affected_rows = $stmt->affected_rows;
        $stmt->free_result();
        $stmt->close();
        $this->close($db);

        return $affected_rows;

    }
    

}

?>