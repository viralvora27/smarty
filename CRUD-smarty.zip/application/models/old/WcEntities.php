<?php 

class WcEntities extends Model {

	protected $id;
    protected $entity_id;
    protected $name;
    protected $image;
    protected $cashback;
     protected $price_cut;
    //protected $db;			


    function __construct()
    {
        parent::__construct();
        $this->table_name = 'wc_entities';
        $this->id='id';
        $this->entity_id='entity_id';
        $this->name='name';
        $this->image='image';
        $this->cashback='cashback';
        $this->price_cut='price_cut';
      
    }

   
   function insertEntities($results)
    {

        $db=$this->open();

        $stmt = $db->prepare("INSERT INTO $this->table_name ($this->entity_id,$this->name,$this->image,$this->price_cut) VALUES (?,?,?,?)");

        $stmt->bind_param('ssss',$results['entity_id'],$results['name'],$results['image'],$results['price_cut']);
        $stmt->execute();

        $wcentities_id = $stmt->insert_id;
        $stmt->free_result();
        $stmt->close();
        $this->close($db);

        return $wcentities_id;

    }
    
    function checkEntities($entity_id)
    {

        //echo $wibmo_acc_no;
        $db=$this->open();
        $stmt = $db->prepare("SELECT $this->entity_id FROM $this->table_name WHERE $this->entity_id=?");
        $stmt->bind_param("d", $entity_id);
        $stmt->execute();

        $stmt->store_result();
        $num_of_rows = $stmt->num_rows;

        $stmt->fetch();

        //close connections
        $stmt->free_result();
        $stmt->close();
        $this->close($db);

        return $num_of_rows;

    }
  
     function getEntities()
    {
        //Open connection
        $db=$this->open();

        $stmt = $db->prepare("SELECT $this->id,$this->entity_id,$this->name,$this->image,$this->cashback,$this->price_cut FROM $this->table_name");
     
        $stmt->execute();

        $stmt->bind_result($id, $entity_id, $name, $image,$cashback,$price_cut);
     
        $entityArray = array();
        
        while ($stmt->fetch()) 
        {
       
          $entity = array("id"=>$id,"entity_id"=>$entity_id,"name"=>$name,"image"=>$image,"cashback"=>$cashback,"price_cut"=>$price_cut);
          array_push($entityArray, $entity);
        }
        
       $stmt->free_result();
       $stmt->close();
       $this->close($db);

     
        

        return $entityArray;

    } 
	
	
   function insertCashback($e_id,$cashback)
    {

        $db=$this->open();

        $stmt = $db->prepare("UPDATE $this->table_name SET $this->cashback=?  WHERE $this->entity_id=?");

      
        $stmt->bind_param('dd',$cashback,$e_id);
     
       
       

        $stmt->execute();
        
        
         
        
        
        $cashback_id = $stmt->affected_rows;
        $stmt->free_result();
        $stmt->close();
        $this->close($db);

        return $cashback_id;

    }

}

?>
