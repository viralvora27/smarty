<?php 

class Users extends Model {

	protected $table_name;
    protected $program_id;
    protected $name;
    protected $email;
    protected $mobile_no;
    protected $wibmo_acc_no;
    protected $created;
    protected $updated;
    //protected $db;
  

    function __construct()
    {
        parent::__construct();
        $this->table_name = 'users';
        $this->program_id='program_id';
        $this->name='name';
        $this->email='email';
        $this->mobile_no='mobile_no';
        $this->wibmo_acc_no='wibmo_acc_no';
        $this->created='created';
        $this->updated='updated';

    }

    function createUser($usersArray)
    {

        $db=$this->open();

        $stmt = $db->prepare("INSERT INTO $this->table_name ($this->program_id,$this->name,$this->email,$this->mobile_no,$this->wibmo_acc_no,$this->created,$this->updated) VALUES (?,?,?,?,?,NOW(),NOW())");

        $stmt->bind_param('sssss',$usersArray['program_id'],$usersArray['name'],$usersArray['email'],$usersArray['mobile_no'],$usersArray['wibmo_acc_no']);
        $stmt->execute();

        $newId = $stmt->insert_id;
        $stmt->free_result();
        $stmt->close();
        $this->close($db);

        return $newId;

    }
    function checkUser($wibmo_acc_no)
    {

        //echo $wibmo_acc_no;
        $db=$this->open();
        $stmt = $db->prepare("SELECT id FROM $this->table_name WHERE $this->wibmo_acc_no=?");
        $stmt->bind_param("s", $wibmo_acc_no);
        $stmt->execute();

        //$stmt->store_result();
        $stmt->bind_result($userid);
        $stmt->fetch();

        //close connections
        $stmt->free_result();
        $stmt->close();
        $this->close($db);

        return $userid;

    }
    

    function getBillers()
    {
        //Open connection
        $db=$this->open();

       // $stmt = $db->prepare("SELECT * FROM $this->table_name WHERE biller_id=?");
        $stmt = $db->prepare("SELECT biller_id, biller_name FROM $this->table_name");

         /* bind parameters for markers */
        //$stmt->bind_param("s", 'ABTSDE');

        /* execute query */
        $stmt->execute();

        /************* bind result *****************/

        /* bind result variables */
        //$stmt->bind_result($billerid,$billername);

        /* fetch value */
       /* $stmt->fetch();
        $data=array();
         while ($stmt->fetch()) {
                $data[]=$billerid;
            }

            /* free results */

        /*********** get result ***********/

        $result = $stmt->get_result();

        $stmt->free_result();

        /* close statement */
        $stmt->close();

        
        //$strSQL = "SELECT * FROM $this->table_name";       
        //$query = mysqli_query($db, $strSQL);   
         
        // Close the connection
        $this->close($db);

       // echo $billerid;

        
        while($row = $result->fetch_assoc())
        {
          $data[]=$row["biller_id"];
        }
       
        

        return $data;

    }
	
	
	

}

?>