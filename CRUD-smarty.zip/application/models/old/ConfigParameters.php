<?php 

class ConfigParameters extends Model {

	protected $id;
    protected $param_id;
    protected $param_value;
    protected $type;
    //protected $db;
  
  				
			
		

    function __construct()
    {
        parent::__construct();
        $this->table_name = 'config_parameters';
        $this->id='id';
        $this->param_id='param_id';
        $this->param_value='param_value';
        $this->type='type';
       
      
    }
    
    function loadAll()
    {
    	//echo $wibmo_acc_no;
        $db=$this->open();
        $stmt = $db->prepare("SELECT $this->id,$this->param_id,$this->param_value,$this->type FROM $this->table_name");
        $stmt->execute();

        $stmt->bind_result($this->id,$this->param_id,$this->param_value,$this->type);
        while($stmt->fetch())
        {        	
        	define($this->param_id, $this->param_value);
        }

        //close connections
        $stmt->free_result();
        $stmt->close();
        $this->close($db);

    }
	
	
   


}

?>