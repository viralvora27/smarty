<?php
/* Smarty version 3.1.29, created on 2016-08-24 10:09:19
  from "/home2/itechnotion/public_html/wibmo/crownit/web/application/views/templates/shared/menu.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57bdb89f633873_77988259',
  'file_dependency' => 
  array (
    '86b16b7b059152d48fd42b8388a3938de0b56f06' => 
    array (
      0 => '/home2/itechnotion/public_html/wibmo/crownit/web/application/views/templates/shared/menu.tpl',
      1 => 1472051329,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57bdb89f633873_77988259 ($_smarty_tpl) {
?>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
   <ul class="nav navbar-right top-nav">
      <li class="dropdown">
         <a href="index.php?route=admin/dashboard"></i> Entites</a>
      </li>     
      <li class="dropdown">
         <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-user"></i> Admin <b class="caret"></b></a>
         <ul class="dropdown-menu">
         <li>
               <a href="index.php?route=admin/change_password"><i class="fa fa-fw fa-key"></i>Change Password</a>
            </li>
            <li>
               <a href="index.php?route=admin/logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
            </li>
         </ul>
      </li>
   </ul>
</nav>
<?php }
}
