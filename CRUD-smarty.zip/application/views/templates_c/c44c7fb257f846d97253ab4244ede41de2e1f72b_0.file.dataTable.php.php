<?php
/* Smarty version 3.1.29, created on 2016-09-12 07:47:22
  from "C:\wamp\www\smartydemo\application\views\templates\shared\dataTable.php" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57d65d8a98e738_60664234',
  'file_dependency' => 
  array (
    'c44c7fb257f846d97253ab4244ede41de2e1f72b' => 
    array (
      0 => 'C:\\wamp\\www\\smartydemo\\application\\views\\templates\\shared\\dataTable.php',
      1 => 1449488206,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57d65d8a98e738_60664234 ($_smarty_tpl) {
?>

 <!--<?php echo '<script'; ?>
 src=" //code.jquery.com/jquery-1.11.3.min.js"><?php echo '</script'; ?>
>
 <?php echo '<script'; ?>
 src="https://cdn.datatables.net/1.10.9/js/jquery.dataTables.min.js"><?php echo '</script'; ?>
>
   <?php echo '<script'; ?>
 src="https://cdn.datatables.net/1.10.9/js/dataTables.bootstrap.min.js"><?php echo '</script'; ?>
>
 

 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.9/css/dataTables.bootstrap.min.css
"/>-->

<?php echo '<script'; ?>
 src="application/public/theme/assets/js/jquery-1.11.3.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="application/public/theme/assets/js/dataTable/jquery.dataTables.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="application/public/theme/assets/js/dataTable/dataTables.bootstrap.min.js" type="text/javascript"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="application/public/theme/assets/css/dataTable/dataTables.bootstrap.min.css" type="text/javascript"><?php echo '</script'; ?>
>

<?php }
}
