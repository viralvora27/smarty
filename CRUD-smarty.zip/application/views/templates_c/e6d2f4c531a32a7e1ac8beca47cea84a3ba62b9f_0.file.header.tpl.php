<?php
/* Smarty version 3.1.29, created on 2016-09-09 13:30:50
  from "C:\wamp\www\crownit\application\views\templates\shared\header.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57d2b98a721ea0_16200588',
  'file_dependency' => 
  array (
    'e6d2f4c531a32a7e1ac8beca47cea84a3ba62b9f' => 
    array (
      0 => 'C:\\wamp\\www\\crownit\\application\\views\\templates\\shared\\header.tpl',
      1 => 1472011570,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57d2b98a721ea0_16200588 ($_smarty_tpl) {
?>
<html>
<!-- https://blackrockdigital.github.io/startbootstrap-sb-admin-->
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title></title>
   
     <link href="public/css/bootstrap.min.css" rel="stylesheet" type="text/css">
     <link href="public/css/bootstrap.css" rel="stylesheet" type="text/css">
     <link href="public/css/sb-admin.css" rel="stylesheet" type="text/css">
    
     <link href="public/css/style.css" rel="stylesheet">
     <link href="public/js/site-demos.css" rel="stylesheet">
     
       <link href="public/font-awesome/css/font-awesome.min.css" rel="stylesheet">

</head>

<body><?php }
}
