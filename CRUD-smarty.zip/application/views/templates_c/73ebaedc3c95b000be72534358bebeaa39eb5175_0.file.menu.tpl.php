<?php
/* Smarty version 3.1.29, created on 2016-09-09 13:34:50
  from "C:\wamp\www\crownit\application\views\templates\shared\menu.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57d2ba7af0def3_34589867',
  'file_dependency' => 
  array (
    '73ebaedc3c95b000be72534358bebeaa39eb5175' => 
    array (
      0 => 'C:\\wamp\\www\\crownit\\application\\views\\templates\\shared\\menu.tpl',
      1 => 1472013530,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57d2ba7af0def3_34589867 ($_smarty_tpl) {
?>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
   <ul class="nav navbar-right top-nav">
      <li class="dropdown">
         <a href="index.php?route=admin/dashboard"></i> Entites</a>
      </li>     
      <li class="dropdown">
         <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-user"></i> Admin <b class="caret"></b></a>
         <ul class="dropdown-menu">
         <li>
               <a href="index.php?route=admin/change_password"><i class="fa fa-fw fa-key"></i>Change Password</a>
            </li>
            <li>
               <a href="index.php?route=admin/logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
            </li>
         </ul>
      </li>
   </ul>
</nav>
<?php }
}
