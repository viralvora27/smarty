<?php
/* Smarty version 3.1.29, created on 2016-09-19 07:24:43
  from "C:\wamp\www\smartydemo\application\views\templates\admin\dashboard.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57df92bbde5516_46898568',
  'file_dependency' => 
  array (
    'c39388726d156ad37ca5c52743123c429c5adee8' => 
    array (
      0 => 'C:\\wamp\\www\\smartydemo\\application\\views\\templates\\admin\\dashboard.tpl',
      1 => 1474269661,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../shared/header.tpl' => 1,
    'file:../shared/menu.tpl' => 1,
    'file:../shared/footer.tpl' => 1,
  ),
),false)) {
function content_57df92bbde5516_46898568 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/menu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>



<style type="text/css">
.center
{
  text-align: center;
}
.dataTables_filter
{
  float: right;
}
#example_paginate
{
  float: right;
}
</style>


<form action="#" method="post" id="myform">
   <div class="container">
      <!-- Navigation -->
      

         <div class="container-fluid">
         
         </div>
         
         <div class="page-header">
               <h1>List Of Students</h1>
            </div>
            
            <!--<div class="alert alert-success successmsg" id="successMessage">
               <strong>Student details updated successfully.</strong>
            </div>-->
            
           <div class='alert alert-success text-center'style='font-size: 15px;display: none;' id="categoryDeleted" >
  Category Deleted Successfully
  <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
  </button>
</div>

<div class='alert alert-danger text-center'style='font-size: 15px;display: none;' id="categoryerror" >something wrong.please try again letter.
 <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span>
 </button>
</div>
<div class="btn-group pull-right">
  <a href="?route=admin/addcategory" class="btn btn-success" >Add Category <i class="fa fa-plus"></i></a>
</div>
<div class="clearfix"></div>
<br/>
<div class="portlet box primary">

 <div class="portlet-body">
 
               <div class="col-xs-12 col-sm-12 col-md-12">
                  <div class="table-responsive">
                     <table id="example" class="table table-hover table-nomargin table-bordered dataTable">
                        <thead>
                           <tr>
                              <th>Name</th>
                              <th>Email</th>
                              <th>Mobile No</th>
                              <th>Profile</th>
                              <th class="header center">Action</th>
                           </tr>
                        </thead>
          <?php
$_from = $_smarty_tpl->tpl_vars['data']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_k_0_saved_item = isset($_smarty_tpl->tpl_vars['k']) ? $_smarty_tpl->tpl_vars['k'] : false;
$_smarty_tpl->tpl_vars['k'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['k']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['k']->value) {
$_smarty_tpl->tpl_vars['k']->_loop = true;
$__foreach_k_0_saved_local_item = $_smarty_tpl->tpl_vars['k'];
?>
           <tbody>
                           <tr id="tr-<?php echo $_smarty_tpl->tpl_vars['k']->value['id'];?>
">
                              <input type="hidden" id="id-<?php echo $_smarty_tpl->tpl_vars['k']->value['id'];?>
" class="field" value="<?php echo $_smarty_tpl->tpl_vars['k']->value['id'];?>
" name="field"/>
                              <td><?php echo $_smarty_tpl->tpl_vars['k']->value['name'];?>
</td>
                              <td><?php echo $_smarty_tpl->tpl_vars['k']->value['email'];?>
</td>
                              <td><?php echo $_smarty_tpl->tpl_vars['k']->value['mob'];?>
</td>
                              <td><img src="category/<?php echo $_smarty_tpl->tpl_vars['k']->value['id'];?>
/<?php echo $_smarty_tpl->tpl_vars['k']->value['image'];?>
" height="70" width="70" /></td>
                              <td class="center"> <a href="?route=admin/editcategory&id=<?php echo $_smarty_tpl->tpl_vars['k']->value['id'];?>
" class="btn btn-success" title='Edit'><i class="fa fa-edit"></i></a>

                  <a data-toggle='modal' style="cursor:pointer" id='id-<?php echo $_smarty_tpl->tpl_vars['k']->value['id'];?>
'  
                    name='getcategoryId' class="btn btn-danger category" title='Delete'  data-target='#deleteModal'>
                    <i class="fa fa-trash"></i>
                  </a>
                </td>
                  </tr>
                  </tbody>
                  <?php
$_smarty_tpl->tpl_vars['k'] = $__foreach_k_0_saved_local_item;
}
if ($__foreach_k_0_saved_item) {
$_smarty_tpl->tpl_vars['k'] = $__foreach_k_0_saved_item;
}
?>
                  </table>
                  </div></div>
                  </div>
                  </div>
 
   </div>
   <!-- /.container -->
</form>

 <!-- for suspend -->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title" id="exampleModalLabel">Confirm</h4>
          </div>
          <div class="modal-body">
            <form>
              <div class="form-group">
                <label for="message-text" class="control-label">Confirm To Delete.</label>
              </div>
            </form>
          </div>
          <input type="hidden" id="hiddencategoryId" value=""/>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-danger btnDelete" data-dismiss="modal" >Delete</button>
          </div>
        </div>
      </div>
    </div>
    
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<?php echo '<script'; ?>
 type="text/javascript">
  
    <?php echo '</script'; ?>
>


    <?php echo '<script'; ?>
 type="text/javascript">

    $(".category").click(function()
    {
      var categoryId=$(this).prop('id').split('-')[1];
//alert(categoryId);
$("#hiddencategoryId").val(categoryId);


});


// for user Suspend//
$(".btnDelete").click(function()
{
	var categoryId=$("#hiddencategoryId").val();
	
	//debugger;
	//alert(categoryId);
  $("#loading").show();
  $.ajax({
   type: "GET",
   url: "?route=admin/deleteCategoryById&categoryId="+categoryId,
  
   success: function(result)
   {
           //alert(result);
           if(result=="0")
		   {
		     $("#categoryerror").show();
		   }
		   else
		   {
             $("#loading").hide();
             $('#tr-'+categoryId).hide();
             $("#categoryerror").hide();
             $("#categoryDeleted").show();
		   }
         }
         
       });
});

<?php echo '</script'; ?>
>

</html><?php }
}
