<?php
/* Smarty version 3.1.29, created on 2016-09-13 06:53:45
  from "C:\wamp\www\smartydemo\application\views\templates\admin\addcategory.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57d7a27942d877_14627395',
  'file_dependency' => 
  array (
    '70862a9ce81bf07252401a19f03f24b056765803' => 
    array (
      0 => 'C:\\wamp\\www\\smartydemo\\application\\views\\templates\\admin\\addcategory.tpl',
      1 => 1473749624,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../shared/header.tpl' => 1,
    'file:../shared/menu.tpl' => 1,
    'file:../shared/footer.tpl' => 1,
  ),
),false)) {
function content_57d7a27942d877_14627395 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/menu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<div class="module_content" style="margin-top:40px;">

	
</div>
<div class="row">
	<div class="col-md-12">
		<br/>
		
		<div class="portlet light">
			<h4 style="text-align: center;">Add Student</h4>
			
            <div class="alert alert-success" id="alert_success" style="display:none; text-align:center;">Student Added Successfully</div>
            

			<div class="portlet-body form">
				<form role="form" class="form-horizontal" method="post" enctype="multipart/form-data">
					<br/>
					<div class='form-body'>
                  
						<div class='form-group'>
							<label class='col-md-3 control-label' for='form_control_1'>Name<span class='required' 
								aria-required='true'>
								* </span>:</label>
								<div class='col-md-6'>
									<input class='form-control' type='text' placeholder='Name' name='txtName' required='required' maxlength='30'
									value="" />
									
								</div>
								<div class='col-md-3'></div>
							</div>
                            
                            <div class='form-group'>
							<label class='col-md-3 control-label' for='form_control_1'>Email<span class='required' 
								aria-required='true'>
								* </span>:</label>
								<div class='col-md-6'>
									<input class='form-control' type='email' placeholder='Email' name='txtemail' required='required' maxlength='30'
									value="" />
									
								</div>
								<div class='col-md-3'></div>
							</div>
                            
                            <div class='form-group'>
							<label class='col-md-3 control-label' for='form_control_1'>Mobile No<span class='required' 
								aria-required='true'>
								* </span>:</label>
								<div class='col-md-6'>
									<input class='form-control' type='text' placeholder='Mobile No' name='txtmobile' required='required' maxlength='30'
									value="" />
									
								</div>
								<div class='col-md-3'></div>
							</div>

							<div class='form-group '>
								<label class='col-md-3 control-label' for='form_control_1'>Profile<span class='required' 
									aria-required='true'>
									* </span>:</label>
									<div class='col-md-6'>
										<input type="file"  name="image" id="image" class='form-control'/> 
										<br/>

										<img id="defaultUser" src="" style="height:175px;;border: #FFF 2px solid; display:none;">
										
										
									</div>
									<div class="col-md-3">
										
									</div>
								</div>


							</div>

							<div class="form-actions">
								<div class="row">
									<div class="col-md-offset-5 col-md-7">
										<a href="?route=admin/dashboard" id="register-back-btn" class="btn btn-default ">Cancel</a>
										<button type="submit"  class="btn btn-success btnsubmit">Submit</button>
									</div>
								</div>
                                 
							</div>
						</form>
					</div>
					

				</div>
			</div>
		</div>

		<br/>
		<br/>

        <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


		<?php echo '<script'; ?>
 type="text/javascript">
		function readURL(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				
				reader.onload = function (e) {
					$('#defaultUser').attr('src', e.target.result);
				}
				
				reader.readAsDataURL(input.files[0]);
			}
		}
		
		$("#image").change(function(){
			var ext = $('#image').val().split('.').pop().toLowerCase();
				if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) 
				{
				$('#defaultuser').hide();
				$("#image").val("");
				alert('invalid extension!');
				}
				else
				{
				readURL(this);
				}
		});
		<?php echo '</script'; ?>
>

  <?php echo '<script'; ?>
 type="text/javascript">
  $(document).ready(function()
  {
	  var url=(window.location.search.substr(1).split('&')[1]).split('=')[1].trim();
     var url1 = window.location.toString();
    // alert(url);
 	 if(url=="1")
  	 {
	 	  $("#alert_success").show();
	 }
	 else
	 {
		 $("#alert_success").hide();
	 }
  });
  
  <?php echo '</script'; ?>
>

</html><?php }
}
