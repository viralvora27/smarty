<?php
/* Smarty version 3.1.29, created on 2016-08-16 15:49:40
  from "/Users/auham/Projects/crownitadmin/application/views/templates/admin/login.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57b319f462b4c7_25308117',
  'file_dependency' => 
  array (
    '10be94e6155d9699ccdcaafb389eabf6c91780f6' => 
    array (
      0 => '/Users/auham/Projects/crownitadmin/application/views/templates/admin/login.tpl',
      1 => 1470995418,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../shared/footer.tpl' => 1,
  ),
),false)) {
function content_57b319f462b4c7_25308117 ($_smarty_tpl) {
?>
<html>
   <!-- https://blackrockdigital.github.io/startbootstrap-sb-admin-->
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="description" content="">
      <meta name="author" content="">
      <title></title>
      <link href="public/css/bootstrap.min.css" rel="stylesheet" type="text/css">
      <link href="public/css/style.css" rel="stylesheet">
      <link href="public/font-awesome/css/font-awesome.min.css" rel="stylesheet">
   </head>
   <body class="imgback">
      <form action="#" method="post" id="page-wrapper">
         <div class="container loginmar" >
       <div class="col-xs-12 col-sm-12 col-md-12">
       <div class="col-xs-3 col-sm-3 col-md-4"></div>
       <div class="col-xs-6 col-sm-6 col-md-4">
        <?php if ($_smarty_tpl->tpl_vars['dt']->value[0] != NULL) {?>
          <?php echo $_smarty_tpl->tpl_vars['dt']->value[0];?>

         <?php }?>
       	</div>
       	<div class="col-xs-3 col-sm-3 col-md-4"></div>
       	</div>
         <div class="col-xs-12 col-sm-12 col-md-12" >
        
     
   

            <div class="col-xs-2 col-sm-2 col-md-3"></div>
            <div class="col-xs-8 col-sm-8 col-md-6" id="login">
               <div class="form-group" >
                  <label>Adminname/Email</label>
                  <input class="form-control" name="adminname" required>
                  <label>Password</label>
                  <input type="password" class="form-control" name="password" required>
               </div>

               <button type="submit" class="btn btn-lg btn-default btnstl">Login</button>
            </div>
            <div class="col-xs-2 col-sm-2 col-md-3"></div>
         </div>
      </form>
      <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
