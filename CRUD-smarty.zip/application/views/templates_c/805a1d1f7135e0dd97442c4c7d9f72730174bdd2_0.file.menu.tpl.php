<?php
/* Smarty version 3.1.29, created on 2016-08-12 11:42:02
  from "/opt/lampp/htdocs/crownit/application/views/templates/shared/menu.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57ad99ea615ff0_70464715',
  'file_dependency' => 
  array (
    '805a1d1f7135e0dd97442c4c7d9f72730174bdd2' => 
    array (
      0 => '/opt/lampp/htdocs/crownit/application/views/templates/shared/menu.tpl',
      1 => 1470994527,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57ad99ea615ff0_70464715 ($_smarty_tpl) {
?>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
   <ul class="nav navbar-right top-nav">
      <li class="dropdown">
         <a href="index.php?route=admin/Dashboard"></i> Entites</a>
      </li>
      <li class="dropdown">
         <a href="index.php?route=admin/GetConfig"></i> Confige</a>
      </li>
      <li class="dropdown">
         <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-user"></i> Admin <b class="caret"></b></a>
         <ul class="dropdown-menu">
         <li>
               <a href="index.php?route=admin/AdminChangePassword"><i class="fa fa-fw fa-key"></i>Change Password</a>
            </li>
            <li>
               <a href="index.php?route=admin/Adminlogout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
            </li>
         </ul>
      </li>
   </ul>
</nav>
<?php }
}
