<?php
/* Smarty version 3.1.29, created on 2016-08-09 12:32:17
  from "/opt/lampp/htdocs/crownit/application/views/templates/commons/error.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57a9b131cb33c1_31356690',
  'file_dependency' => 
  array (
    '2b7f7a4cc03c07d9f91b3d3a7da2c3a72d1bdeba' => 
    array (
      0 => '/opt/lampp/htdocs/crownit/application/views/templates/commons/error.tpl',
      1 => 1470326399,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../shared/header.tpl' => 1,
    'file:../shared/footer.tpl' => 1,
  ),
),false)) {
function content_57a9b131cb33c1_31356690 ($_smarty_tpl) {
ob_start();
echo $_smarty_tpl->tpl_vars['title']->value;
$_tmp1=ob_get_clean();
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>$_tmp1), 0, false);
?>


<div style="height:400px" class="text-center">
	<br />
	<br />
<h4 class="text-center"><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</h4>
<br />
<br />
<br />
<br />
<a href="#" class="btn btn-success btn-lg">Go Back</a>
</div>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
