<?php
/* Smarty version 3.1.29, created on 2016-09-10 12:36:21
  from "C:\wamp\www\smartydemo\application\views\templates\shared\footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57d3fe4532ebd7_07228957',
  'file_dependency' => 
  array (
    '0119e67f8e68b55cc7e149cec182a731b7e77e18' => 
    array (
      0 => 'C:\\wamp\\www\\smartydemo\\application\\views\\templates\\shared\\footer.tpl',
      1 => 1472011580,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57d3fe4532ebd7_07228957 ($_smarty_tpl) {
?>
</body>
<?php echo '<script'; ?>
 src="public/js/jquery.js"><?php echo '</script'; ?>
>
 <?php echo '<script'; ?>
 src="public/js/bootstrap.min.js"><?php echo '</script'; ?>
>

<?php }
}
