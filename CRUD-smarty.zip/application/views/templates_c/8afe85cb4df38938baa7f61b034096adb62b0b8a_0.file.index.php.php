<?php
/* Smarty version 3.1.29, created on 2016-08-11 08:04:10
  from "/opt/lampp/htdocs/crownit/index.php" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57ac155a5524d4_70567938',
  'file_dependency' => 
  array (
    '8afe85cb4df38938baa7f61b034096adb62b0b8a' => 
    array (
      0 => '/opt/lampp/htdocs/crownit/index.php',
      1 => 1470808537,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57ac155a5524d4_70567938 ($_smarty_tpl) {
echo '<?php
';?>/*
 *---------------------------------------------------------------
 * APPLICATION ENVIRONMENT
 *---------------------------------------------------------------
 *
 * You can load different configurations depending on your
 * current environment. Setting the environment also influences
 * things like logging and error reporting.
 *
 * This can be set to anything, but default usage is:
 *
 *     development
 *     testing
 *     production
 *
 * NOTE: If you change these, also change the error_reporting() code below
 *
 */
define('ENVIRONMENT', 'development');
//define('ENVIRONMENT', 'testing');
//define('ENVIRONMENT', 'production');
define('SITE_PATH', realpath(dirname(__FILE__) . '/application'));
define('LIBRARY_PATH', realpath(dirname(__FILE__) . '/application/libs'));
define('TEMPLATE_PATH', realpath(dirname(__FILE__) . '/application/views/'));
define('SSL_VERIFY',false); // by pass SSL

/*
 *---------------------------------------------------------------
 * ERROR REPORTING
 *---------------------------------------------------------------
 *
 * Different environments will require different levels of error reporting.
 * By default development will show errors but testing and live will hide them.
 */

if (defined('ENVIRONMENT'))
{

	switch (ENVIRONMENT)
	{
		case 'development':
			error_reporting(E_ALL);
			ini_set( "display_errors", 1 );
		break;
	
		case 'testing':
		case 'production':
			error_reporting(0);
		break;

		default:
			exit('The application environment is not set correctly.');
	}
}

session_start();

$uri = array();

if( isset( $_GET['route'] ) ){ 
	$array_tmp_uri = preg_split('[\\/]', $_GET['route'], -1, PREG_SPLIT_NO_EMPTY);
	$uri['controller'] = @ $array_tmp_uri[0];
	$uri['method']     = @ $array_tmp_uri[1];
	$uri['var']        = @ $array_tmp_uri[2];
}
else{
	$uri['controller'] = "admin";
	$uri['method']     = "login"; 
	$uri['var']        = ""; 
}

//Load config and base 
require_once("config.php"); 
require_once("application/base.php"); 

//loads controller
$application = new Application( $uri );
<?php }
}
