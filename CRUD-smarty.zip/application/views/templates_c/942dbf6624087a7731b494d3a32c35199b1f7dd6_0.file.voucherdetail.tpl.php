<?php
/* Smarty version 3.1.29, created on 2016-08-09 13:41:33
  from "/opt/lampp/htdocs/crownit/application/views/templates/user/voucherdetail.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57a9c16dd28233_53940035',
  'file_dependency' => 
  array (
    '942dbf6624087a7731b494d3a32c35199b1f7dd6' => 
    array (
      0 => '/opt/lampp/htdocs/crownit/application/views/templates/user/voucherdetail.tpl',
      1 => 1470312934,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../shared/header.tpl' => 1,
    'file:../shared/menu.tpl' => 1,
    'file:../shared/wibmostrip.tpl' => 1,
    'file:../shared/footer.tpl' => 1,
  ),
),false)) {
function content_57a9c16dd28233_53940035 ($_smarty_tpl) {
ob_start();
echo $_smarty_tpl->tpl_vars['title']->value;
$_tmp1=ob_get_clean();
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>$_tmp1), 0, false);
?>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/menu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('active'=>'active1'), 0, false);
?>


   

<div class="row text-center"><h3><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</h3></div>

<div class="row text-center boxfull">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class=""><img src="img/content/flipcart.jpg" height="100px" width="300px"></div> 
	</div>
</div>
<div class="row text-center"><h3>Flip Kart</h3></div>

<div class="row boxhistory">
	<div class="col-md-6 col-sm-6 col-xs-6 text-left"><h4>Qty</h4></div>
		<div class="col-md-6 col-sm-6 col-xs-6 text-right">
			<h4>
				<select class="" required="true">
		          <option value="Qty">1</option>
		          <option value="Qty">2</option>
		        </select>
		     </h4>
		</div>
</div>
<br/>
<div class="row boxhistory">
	<div class="col-md-6 col-sm-6 col-xs-6 text-left"><h4>Choose Amount</h4></div>
	<div class="col-md-6 col-sm-6 col-xs-6 text-right">
		<h4>
			<select class="" required="true">
		          <option value="Qty">500</option>
		           <option value="Qty">600</option>
		    </select>	
		 </h4>
	</div>
</div>


 <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/wibmostrip.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<br/>
<div class="row text-center">
<a href="index.html" class="btn btn-default btn-lg">Back</a>
<a href="vsuccsee.html" class="btn btn-success btn-lg">Buy</a>
</div>
<br/>



<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
