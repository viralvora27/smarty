<?php
/* Smarty version 3.1.29, created on 2017-01-23 09:15:07
  from "C:\wamp\www\SMARTY\smartydemo_CRUD\application\views\templates\shared\menu.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5885c99ba81ca6_09029417',
  'file_dependency' => 
  array (
    '014352dbe3b688a9ab09848141e5a8edb1302716' => 
    array (
      0 => 'C:\\wamp\\www\\SMARTY\\smartydemo_CRUD\\application\\views\\templates\\shared\\menu.tpl',
      1 => 1473667566,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5885c99ba81ca6_09029417 ($_smarty_tpl) {
?>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
   <ul class="nav navbar-right top-nav">
      <!--<li class="dropdown">
         <a href="index.php?route=admin/dashboard"></i> Entites</a>
      </li>  -->   
      <li class="dropdown">
         <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-user"></i> Admin <b class="caret"></b></a>
         <ul class="dropdown-menu">
        <!-- <li>
               <a href="index.php?route=admin/change_password"><i class="fa fa-fw fa-key"></i>Change Password</a>
            </li>-->
            <li>
               <a href="index.php?route=admin/logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
            </li>
         </ul>
      </li>
   </ul>
</nav>
<?php }
}
