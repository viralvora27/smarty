<?php
/* Smarty version 3.1.29, created on 2016-08-24 09:46:37
  from "/home2/itechnotion/public_html/wibmo/crownit/web/application/views/templates/shared/header.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57bdb34d15a7d6_04385746',
  'file_dependency' => 
  array (
    'efac76493dcd3c84420f5f982730e3931a9368b4' => 
    array (
      0 => '/home2/itechnotion/public_html/wibmo/crownit/web/application/views/templates/shared/header.tpl',
      1 => 1472049369,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57bdb34d15a7d6_04385746 ($_smarty_tpl) {
?>
<html>
<!-- https://blackrockdigital.github.io/startbootstrap-sb-admin-->
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title></title>
   
     <link href="public/css/bootstrap.min.css" rel="stylesheet" type="text/css">
     <link href="public/css/bootstrap.css" rel="stylesheet" type="text/css">
     <link href="public/css/sb-admin.css" rel="stylesheet" type="text/css">
    
     <link href="public/css/style.css" rel="stylesheet">
     <link href="public/js/site-demos.css" rel="stylesheet">
     
       <link href="public/font-awesome/css/font-awesome.min.css" rel="stylesheet">

</head>

<body><?php }
}
