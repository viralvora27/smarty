<?php
/* Smarty version 3.1.29, created on 2016-08-11 15:51:27
  from "/opt/lampp/htdocs/crownit/application/views/templates/shared/footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57ac82df4abea7_45892149',
  'file_dependency' => 
  array (
    '668d51d0d2feff1318de940d3d606c65e2e5d6ec' => 
    array (
      0 => '/opt/lampp/htdocs/crownit/application/views/templates/shared/footer.tpl',
      1 => 1470923482,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57ac82df4abea7_45892149 ($_smarty_tpl) {
?>
</body>
<?php echo '<script'; ?>
 src="public/js/jquery.js"><?php echo '</script'; ?>
>
 <?php echo '<script'; ?>
 src="public/js/bootstrap.min.js"><?php echo '</script'; ?>
>

</html><?php }
}
