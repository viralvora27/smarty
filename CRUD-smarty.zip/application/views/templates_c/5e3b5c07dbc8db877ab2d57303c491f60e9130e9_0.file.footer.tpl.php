<?php
/* Smarty version 3.1.29, created on 2017-01-23 09:14:59
  from "C:\wamp\www\SMARTY\smartydemo_CRUD\application\views\templates\shared\footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5885c993f1b975_88468535',
  'file_dependency' => 
  array (
    '5e3b5c07dbc8db877ab2d57303c491f60e9130e9' => 
    array (
      0 => 'C:\\wamp\\www\\SMARTY\\smartydemo_CRUD\\application\\views\\templates\\shared\\footer.tpl',
      1 => 1472011580,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5885c993f1b975_88468535 ($_smarty_tpl) {
?>
</body>
<?php echo '<script'; ?>
 src="public/js/jquery.js"><?php echo '</script'; ?>
>
 <?php echo '<script'; ?>
 src="public/js/bootstrap.min.js"><?php echo '</script'; ?>
>

<?php }
}
