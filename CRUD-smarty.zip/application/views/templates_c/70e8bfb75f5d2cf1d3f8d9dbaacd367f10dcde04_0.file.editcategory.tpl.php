<?php
/* Smarty version 3.1.29, created on 2016-09-19 08:17:10
  from "C:\wamp\www\smartydemo\application\views\templates\admin\editcategory.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57df9f061133a8_97077938',
  'file_dependency' => 
  array (
    '70e8bfb75f5d2cf1d3f8d9dbaacd367f10dcde04' => 
    array (
      0 => 'C:\\wamp\\www\\smartydemo\\application\\views\\templates\\admin\\editcategory.tpl',
      1 => 1474272976,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../shared/header.tpl' => 1,
    'file:../shared/menu.tpl' => 1,
    'file:../shared/footer.tpl' => 1,
  ),
),false)) {
function content_57df9f061133a8_97077938 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/menu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<div class="module_content" style="margin-top:40px;">
 <!--<div class="alert alert-success successmsg" id="successMessage">
               <strong>Student details updated successfully.</strong> 
            </div>	-->
            <!--<?php if ($_smarty_tpl->tpl_vars['message']->value != null) {?>
            <div class="alert alert-success"><?php echo $_smarty_tpl->tpl_vars['message']->value;?>
</div>
            <?php }?>-->
           
</div>

<div class="row">
	<div class="col-md-12">
		<br/>
		
		<div class="portlet light">
			<h4 style="text-align: center;">Edit Student</h4>
            
              <div class="alert alert-success" id="alert_success" style="display:none; text-align:center;">Student Updated Successfully</div>
            
			<div class="portlet-body form">
				<form role="form" class="form-horizontal" method="post" enctype="multipart/form-data">
					<br/>
					<div class='form-body'>
                     <?php
$_from = $_smarty_tpl->tpl_vars['data']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_k_0_saved_item = isset($_smarty_tpl->tpl_vars['k']) ? $_smarty_tpl->tpl_vars['k'] : false;
$_smarty_tpl->tpl_vars['k'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['k']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['k']->value) {
$_smarty_tpl->tpl_vars['k']->_loop = true;
$__foreach_k_0_saved_local_item = $_smarty_tpl->tpl_vars['k'];
?>
						<input type="hidden" id="categoryId" name="categoryId" value="<?php echo $_smarty_tpl->tpl_vars['k']->value['id'];?>
"/>
						<div class='form-group'>
							<label class='col-md-3 control-label' for='form_control_1'>Name<span class='required' 
								aria-required='true'>
								* </span>:</label>
								<div class='col-md-6'>
									<input class='form-control' type='text' placeholder='Name' name='txtName' required='required' maxlength='30'
									value="<?php echo $_smarty_tpl->tpl_vars['k']->value['name'];?>
" />
									
								</div>
								<div class='col-md-3'></div>
							</div>
                            
                            <div class='form-group'>
							<label class='col-md-3 control-label' for='form_control_1'>Email<span class='required' 
								aria-required='true'>
								* </span>:</label>
								<div class='col-md-6'>
									<input class='form-control' type='email' placeholder='Email' name='txtemail' required='required' maxlength='30'
									value="<?php echo $_smarty_tpl->tpl_vars['k']->value['email'];?>
" />
									
								</div>
								<div class='col-md-3'></div>
							</div>
                            
                            <div class='form-group'>
							<label class='col-md-3 control-label' for='form_control_1'>Mobile No<span class='required' 
								aria-required='true'>
								* </span>:</label>
								<div class='col-md-6'>
									<input class='form-control' type='text' placeholder='Mobile No' name='txtmobile' required='required' maxlength='30'
									value="<?php echo $_smarty_tpl->tpl_vars['k']->value['mob'];?>
" />
									
								</div>
								<div class='col-md-3'></div>
							</div>

							<div class='form-group '>
								<label class='col-md-3 control-label' for='form_control_1'>Profile<span class='required' 
									aria-required='true'>
									* </span>:</label>
									<div class='col-md-6'>
										<input type="file"  name="image" id="image" class='form-control'/> 
										<br/>
                                        <input type="hidden" name="txtimg" value="<?php echo $_smarty_tpl->tpl_vars['k']->value['image'];?>
" />
										<img id="defaultUser" src="category/<?php echo $_smarty_tpl->tpl_vars['k']->value['id'];?>
/<?php echo $_smarty_tpl->tpl_vars['k']->value['image'];?>
" style="height:175px;;border: #FFF 2px solid;">
										
										
									</div>
									<div class="col-md-3">
										
									</div>
								</div>


							</div>

							<div class="form-actions">
								<div class="row">
									<div class="col-md-offset-5 col-md-7">
										<a href="?route=admin/dashboard" id="register-back-btn" class="btn btn-default ">Cancel</a>
										<button type="submit"  class="btn btn-success btnsubmit">Submit</button>
									</div>
								</div>
                                 <?php
$_smarty_tpl->tpl_vars['k'] = $__foreach_k_0_saved_local_item;
}
if ($__foreach_k_0_saved_item) {
$_smarty_tpl->tpl_vars['k'] = $__foreach_k_0_saved_item;
}
?>
							</div>
						</form>
					</div>
					

				</div>
			</div>
		</div>

		<br/>
		<br/>

        <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


		<?php echo '<script'; ?>
 type="text/javascript">
		function readURL(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				
				reader.onload = function (e) {
					$('#defaultUser').attr('src', e.target.result);
				}
				
				reader.readAsDataURL(input.files[0]);
			}
		}
		
		$("#image").change(function(){
			var ext = $('#image').val().split('.').pop().toLowerCase();
				if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) 
				{
				$('#defaultuser').hide();
				$("#image").val("");
				alert('invalid extension!');
				}
				else
				{
				readURL(this);
				}
		});
		
		<?php echo '</script'; ?>
>
        
         <?php echo '<script'; ?>
 type="text/javascript">
  $(document).ready(function()
  {
	  var url=(window.location.search.substr(1).split('&')[2]).split('=')[1].trim();
     var url1 = window.location.toString();
    // alert(url);
 	 if(url=="1")
  	 {
	 	  $("#alert_success").show();
	 }
	 else
	 {
		 $("#alert_success").hide();
	 }
  });
  
  <?php echo '</script'; ?>
>


</html><?php }
}
