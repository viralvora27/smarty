<?php
/* Smarty version 3.1.29, created on 2016-08-16 15:49:48
  from "/Users/auham/Projects/crownitadmin/application/views/templates/admin/dashboard.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57b319fc39a224_52473252',
  'file_dependency' => 
  array (
    'ceedd39a4e6312366792b5fc1508faf73e71e9fa' => 
    array (
      0 => '/Users/auham/Projects/crownitadmin/application/views/templates/admin/dashboard.tpl',
      1 => 1470992469,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../shared/header.tpl' => 1,
    'file:../shared/menu.tpl' => 1,
    'file:../shared/footer.tpl' => 1,
  ),
),false)) {
function content_57b319fc39a224_52473252 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<form action="#" method="post" id="myform">
   <div class="container">
      <!-- Navigation -->
      <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/menu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


         <div class="container-fluid">
            <div class="alert alert-success successmsg" id="successMessage">
               <strong>Well done!</strong> You successfully Insert Cashback.
            </div>
           <div class="alert alert-danger successmsg" id="unsuccessMessage">
                    <strong></strong> Feild Is Required. Or Must Be One And Tow Digit.
                </div>
               
                   
      
        
       	</div>
            <div class="page-header">
               <h1>List Of Entites</h1>
            </div>
           
               <div class="col-xs-12 col-sm-12 col-md-12">
                  <div class="table-responsive">
                     <table class="table table-hover">
                        <thead>
                           <tr>
                              <th>Entities Id</th>
                              <th>Name</th>
                              <th>Image</th>
                              <th>Cash Back</th>
                           </tr>
                        </thead>
                        <?php
$_from = $_smarty_tpl->tpl_vars['data']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_k_0_saved_item = isset($_smarty_tpl->tpl_vars['k']) ? $_smarty_tpl->tpl_vars['k'] : false;
$_smarty_tpl->tpl_vars['k'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['k']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['k']->value) {
$_smarty_tpl->tpl_vars['k']->_loop = true;
$__foreach_k_0_saved_local_item = $_smarty_tpl->tpl_vars['k'];
?>
                        <tbody>
                           <tr>
                              <input type="hidden" id="id-<?php echo $_smarty_tpl->tpl_vars['k']->value['entity_id'];?>
" class="field" value="<?php echo $_smarty_tpl->tpl_vars['k']->value['id'];?>
" name="field"/>
                              <td><?php echo $_smarty_tpl->tpl_vars['k']->value['entity_id'];?>
</td>
                              <td><?php echo $_smarty_tpl->tpl_vars['k']->value['name'];?>
</td>
                              <td><img src="<?php echo $_smarty_tpl->tpl_vars['k']->value['image'];?>
" height="100" width="200" /></td>
                              <td>
                                 <input class="form-control txtcashback quantity"  value="<?php echo $_smarty_tpl->tpl_vars['k']->value['cashback'];?>
" id="cashback-<?php echo $_smarty_tpl->tpl_vars['k']->value['entity_id'];?>
" name="quantity" type="text" maxlength="2" require/>
                              </td>
                              <td>
                                 <button type="button" class="btn btn-default btnCashback" value="<?php echo $_smarty_tpl->tpl_vars['k']->value['entity_id'];?>
" id="btn-<?php echo $_smarty_tpl->tpl_vars['k']->value['entity_id'];?>
">Add Cashback</button>


                                
                  </div>
                  </td>
                  </tr>
                  </tbody>
                  <?php
$_smarty_tpl->tpl_vars['k'] = $__foreach_k_0_saved_local_item;
}
if ($__foreach_k_0_saved_item) {
$_smarty_tpl->tpl_vars['k'] = $__foreach_k_0_saved_item;
}
?>
                  </table>
                  </div></div></div></div>
            </div>
         </div>
      </div>
   </div>
   <!-- /.container-fluid -->
   </div>
   <!-- /#page-wrapper -->
   </div>
</form>
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<?php echo '<script'; ?>
>

 




$(document).ready(function () {
  //called when key is pressed in textbox

  $(".quantity").keypress(function (e) {
     //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        //display error message

        $("#errmsg").html("Digits Only").show().fadeOut("slow");
               return false;
    }
   

   });



});



   $(".btnCashback").click(function(){
   
   	var entityid = $(this).val();
   	var cashback= $("#cashback-"+entityid).val();

   
   	

   	
   	
   	$.ajax({
   		type:"GET",
   		url:"index.php?route=admin/CashbackInsert&entityid="+entityid+"&cashback="+cashback,
   		success:function(result)
   		{	
   			if(result==0)
   			{
   				setTimeout(function(){ $("#successMessage").show(1000);});

   				setTimeout(function(){ $("#unsuccessMessage").hide(1000);});
   			

   		}
   		else if(result!=0)
   		{
   			setTimeout(function(){ $("#unsuccessMessage").show(1000);});
   			setTimeout(function(){ $("#successMessage").hide(1000);});
   		}
   		

   		}
   
   	});
   });
   
   
<?php echo '</script'; ?>
><?php }
}
