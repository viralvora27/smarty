<?php
/* Smarty version 3.1.29, created on 2016-08-16 15:49:48
  from "/Users/auham/Projects/crownitadmin/application/views/templates/shared/header.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57b319fc783517_38724067',
  'file_dependency' => 
  array (
    '31d171c2160ae48635ba6ca44a78246aafab9cfc' => 
    array (
      0 => '/Users/auham/Projects/crownitadmin/application/views/templates/shared/header.tpl',
      1 => 1470994382,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57b319fc783517_38724067 ($_smarty_tpl) {
?>
<html>
<!-- https://blackrockdigital.github.io/startbootstrap-sb-admin-->
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title></title>
   
     <link href="public/css/bootstrap.min.css" rel="stylesheet" type="text/css">
     <link href="public/css/bootstrap.css" rel="stylesheet" type="text/css">
     <link href="public/css/sb-admin.css" rel="stylesheet" type="text/css">
    
     <link href="public/css/style.css" rel="stylesheet">
     <link href="public/js/site-demos.css" rel="stylesheet">
     
       <link href="public/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<?php echo '<script'; ?>
 type = "text/javascript" 
         src = "http://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"><?php echo '</script'; ?>
>
</head>

<body><?php }
}
