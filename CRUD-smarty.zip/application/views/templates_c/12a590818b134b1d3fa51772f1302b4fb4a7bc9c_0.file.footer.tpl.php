<?php
/* Smarty version 3.1.29, created on 2016-09-09 13:30:50
  from "C:\wamp\www\crownit\application\views\templates\shared\footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57d2b98a7349c8_29183301',
  'file_dependency' => 
  array (
    '12a590818b134b1d3fa51772f1302b4fb4a7bc9c' => 
    array (
      0 => 'C:\\wamp\\www\\crownit\\application\\views\\templates\\shared\\footer.tpl',
      1 => 1472011580,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57d2b98a7349c8_29183301 ($_smarty_tpl) {
?>
</body>
<?php echo '<script'; ?>
 src="public/js/jquery.js"><?php echo '</script'; ?>
>
 <?php echo '<script'; ?>
 src="public/js/bootstrap.min.js"><?php echo '</script'; ?>
>

<?php }
}
