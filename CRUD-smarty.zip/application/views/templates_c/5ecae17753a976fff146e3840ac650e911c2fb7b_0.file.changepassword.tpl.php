<?php
/* Smarty version 3.1.29, created on 2016-09-09 13:35:50
  from "C:\wamp\www\crownit\application\views\templates\admin\changepassword.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57d2bab6750435_50723202',
  'file_dependency' => 
  array (
    '5ecae17753a976fff146e3840ac650e911c2fb7b' => 
    array (
      0 => 'C:\\wamp\\www\\crownit\\application\\views\\templates\\admin\\changepassword.tpl',
      1 => 1472013240,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../shared/header.tpl' => 1,
    'file:../shared/menu.tpl' => 1,
    'file:../shared/footer.tpl' => 1,
  ),
),false)) {
function content_57d2bab6750435_50723202 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<form action="" class="pure-form">
   <div class="container loginmar">
      <!-- Navigation -->
      <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/menu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


         <div class="col-xs-12 col-sm-12 col-md-12 ">
            <div class="col-xs-3 col-sm-3 col-md-3 "></div>
            <div class="col-xs-6 col-sm-6 col-md-6 ">
            <div class="alert alert-success successmsg text-center" id="successMessage">
               
            </div>
           
           </div>
           <div class="col-xs-3 col-sm-3 col-md-3 "></div>
           </div>
           
               <div class="col-xs-12 col-sm-12 col-md-12 ">
                <div class="col-xs-1 col-sm-1 col-md-4"></div>
                 <div class="col-xs-10 col-sm-10 col-md-4">
                  <div class="form-group">
                                
                                <input type="password" class="form-control masked" placeholder="New Password" id="pwd" name="password" required >
                                </input>
                                </br>
                                 <input type="password" class="form-control" placeholder="Repeat Password" id="pwd1"  name="password" required >
                                 </input>
                                
                              <!--   <button type="button" id="eye">
    <img src="https://cdn0.iconfinder.com/data/icons/feather/96/eye-16.png" alt="eye" />
</button></br>--></br>
                                 <button type="button" id="btnChangepw" class="btn btn-lg btn-default btnstl pure-button pure-button-primary">Change Password</button>
                            </div>
                  </div>
                             <div class="col-xs-1 col-sm-1 col-md-4"></div>

                           </div>
            
   <!-- /.container-fluid -->
   
   <!-- /#page-wrapper -->
   </div>
</form>
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php echo '<script'; ?>
>
   $("#btnChangepw").click(function(){
   
   	
   	var pwd= $("#pwd").val();
        var cpwd=$("#pwd1").val();
        
        if(pwd==cpwd)
        {
   	
   	$.ajax({
   		type:"POST",
   		url:"index.php?route=admin/UpdatePassword&pwd="+pwd+"&cpwd="+cpwd,
   		success:function(result)
   		{   			
		       $("#successMessage").html(result).show();
		       
   		}
   
   	});
   	}
   	else
   	{
   	 $("#successMessage").html("Both Password should be same").show();
   	}
   });
   
<?php echo '</script'; ?>
>

</html>

<?php }
}
