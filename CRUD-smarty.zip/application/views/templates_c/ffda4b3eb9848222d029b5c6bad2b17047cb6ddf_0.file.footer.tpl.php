<?php
/* Smarty version 3.1.29, created on 2016-08-16 15:49:40
  from "/Users/auham/Projects/crownitadmin/application/views/templates/shared/footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57b319f47590a8_14555282',
  'file_dependency' => 
  array (
    'ffda4b3eb9848222d029b5c6bad2b17047cb6ddf' => 
    array (
      0 => '/Users/auham/Projects/crownitadmin/application/views/templates/shared/footer.tpl',
      1 => 1470923482,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57b319f47590a8_14555282 ($_smarty_tpl) {
?>
</body>
<?php echo '<script'; ?>
 src="public/js/jquery.js"><?php echo '</script'; ?>
>
 <?php echo '<script'; ?>
 src="public/js/bootstrap.min.js"><?php echo '</script'; ?>
>

</html><?php }
}
