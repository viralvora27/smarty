<?php
/* Smarty version 3.1.29, created on 2016-08-24 23:48:13
  from "/home2/itechnotion/public_html/wibmo/crownit/web/application/views/templates/admin/login.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57be788d7daef6_43074654',
  'file_dependency' => 
  array (
    '92cd3e00ad5902900fe980d61755ca9d2a2786eb' => 
    array (
      0 => '/home2/itechnotion/public_html/wibmo/crownit/web/application/views/templates/admin/login.tpl',
      1 => 1472100476,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../shared/header.tpl' => 1,
    'file:../shared/footer.tpl' => 1,
  ),
),false)) {
function content_57be788d7daef6_43074654 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

      <form action="#" method="post" id="page-wrapper">
         <div class="container" >
       
         <div class="col-xs-12 col-sm-12 col-md-12" >
        
     
   

            <div class="col-xs-2 col-sm-2 col-md-3"></div>
            <div class="col-xs-8 col-sm-8 col-md-6" id="login">
            <?php if ($_smarty_tpl->tpl_vars['message']->value != null) {?>
            <div class="alert alert-success"><?php echo $_smarty_tpl->tpl_vars['message']->value;?>
</div>
            <?php }?>
       
               <div class="form-group" >
                  <label>Adminname/Email</label>
                  <input class="form-control" name="adminname" required>
                  <label>Password</label>
                  <input type="password" class="form-control" name="password" required>
               </div>

               <button type="submit" class="btn btn-lg btn-default btnstl">Login</button>
            </div>
            <div class="col-xs-2 col-sm-2 col-md-3"></div>
         </div>
      </form>
      <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../shared/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

      
      </html>
<?php }
}
