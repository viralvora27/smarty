<?php
/* Smarty version 3.1.29, created on 2017-01-23 09:14:59
  from "C:\wamp\www\SMARTY\smartydemo_CRUD\application\views\templates\shared\header.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5885c993eba525_58526053',
  'file_dependency' => 
  array (
    '5481565500eac2da07195b1046d50211b97cc38c' => 
    array (
      0 => 'C:\\wamp\\www\\SMARTY\\smartydemo_CRUD\\application\\views\\templates\\shared\\header.tpl',
      1 => 1472011570,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5885c993eba525_58526053 ($_smarty_tpl) {
?>
<html>
<!-- https://blackrockdigital.github.io/startbootstrap-sb-admin-->
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title></title>
   
     <link href="public/css/bootstrap.min.css" rel="stylesheet" type="text/css">
     <link href="public/css/bootstrap.css" rel="stylesheet" type="text/css">
     <link href="public/css/sb-admin.css" rel="stylesheet" type="text/css">
    
     <link href="public/css/style.css" rel="stylesheet">
     <link href="public/js/site-demos.css" rel="stylesheet">
     
       <link href="public/font-awesome/css/font-awesome.min.css" rel="stylesheet">

</head>

<body><?php }
}
