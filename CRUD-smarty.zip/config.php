<?php
{
// server info
$server = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'smartydemo';
 
}